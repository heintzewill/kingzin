# Roadmap e critérios de aceitação

## Fase alpha 0.1 (este pacote)

- [x] Projeto Kotlin + Jetpack Compose
- [x] Manifest com HOME e LAUNCHER
- [x] Navegação entre oito seções
- [x] Cores e persistência de tema
- [x] Pesquisa e abertura de aplicativos listáveis
- [x] Parser e execução de comandos internos
- [x] Telemetria Android de bateria, RAM e armazenamento
- [x] Histórico local simples de RAM e armazenamento
- [x] Assistente offline de regras
- [x] Cliente opcional Chat Completions por API
- [x] Globo animado projetado matematicamente em Canvas
- [x] Teste ativo de endpoint HTTPS
- [x] SSH para execução de um comando com pin de chave SHA256
- [x] Configuração de build no GitHub Actions
- [ ] Compilação integral do projeto Android **não executada neste ambiente**
- [ ] Teste real no POCO X7 5G

Os itens marcados `[x]` significam código-fonte implementado, **não validação em execução de APK**.

## Alpha 0.2 — Consolidação

- Compilar e testar no GitHub Actions.
- Corrigir erros detectados pelo build.
- Registrar capturas de tela de cada aba no telefone real.
- Implementar testes instrumentados de navegação.
- Atualizar SDK e bibliotecas conforme necessidade.
- Melhorar ícones, cores e acessibilidade.

## Alpha 0.3 — Recursos de launcher

- Widgets Android, dock e favoritos.
- Pesquisa assíncrona e atualização da lista de apps.
- Atalhos, gestos e organização por pastas.
- Histórico e sugestões locais de pesquisa.

## Alpha 0.4 — Terminal / desenvolvimento

- Sessões PTY locais no ambiente permitido.
- Gerenciador de arquivos com Storage Access Framework.
- Editor de código e interpretação delimitada por runtime.
- Comandos com autocomplete e guias por sessão.

## Alpha 0.5 — IA e automações

- Integração de ferramentas tipadas e confirmação de ações.
- Motor de automação controlado.
- Histórico local de conversas com gestão de retenção.
- Integrações de provedores adicionais.

## Alpha 0.6 — Global & Remote

- SFTP.
- SSH com autenticação por chave e sessões interativas.
- Cadastro de hosts protegido.
- Marcadores geográficos user-provided no globo.
- Melhorias de desempenho no desenho 3D.

## Critérios para release

Compilação Android bem-sucedida + testes instrumentados + revisão de permissões + verificação de SSL/SSH + testes reais de dispositivo + ausência de crashes críticos.

# Referência: eDex_UI_7.2.0.apk

Análise estática restrita ao inventário do conteúdo do ZIP APK fornecido. Não envolve execução ou decompilação proprietária.

Itens identificados no pacote:

- `assets/globe/`: implementações JavaScript, HTML e recursos de globo 3D.
- `assets/theme.json`, `assets/themes.json`: metadados relacionados à aparência.
- `res/layout/activity_terminal.xml`: layout de terminal.
- `res/layout/layout_plugin_cpu.xml`: layout de indicador de CPU.
- `res/layout/layout_plugin_notifications.xml`: layout de notificações.
- `res/layout/layout_plugin_globe.xml`: layout para globo.
- `res/layout/layout_plugin_memory.xml`: layout de memória.
- `res/layout/layout_plugin_coding.xml`: layout de editor/código.
- `res/layout/fragment_configurations.xml`: configurações.
- `res/layout/layout_plugins.xml`: área de plugins.

**Limite da evidência:** layouts e assets não bastam para confirmar a operação completa dos recursos nem seu comportamento em tempo de execução.

O NEXUS foi escrito independentemente, sem redistribuir ícones, fontes, código, scripts ou imagens do APK original.

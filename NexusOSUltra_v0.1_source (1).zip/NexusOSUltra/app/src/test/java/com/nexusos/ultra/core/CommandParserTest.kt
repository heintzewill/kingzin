package com.nexusos.ultra.core

import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    @Test fun parsesCommands() {
        assertEquals(listOf("nexus", "apps", "list"), CommandParser.tokenize("nexus apps list"))
    }
    @Test fun parsesQuotedName() {
        assertEquals(listOf("open", "Free Fire MAX"), CommandParser.tokenize("open \"Free Fire MAX\""))
    }
    @Test fun parsesWhitespace() {
        assertEquals(listOf("battery"), CommandParser.tokenize("   battery   "))
    }
    @Test fun emptyInput() { assertEquals(emptyList<String>(), CommandParser.tokenize("   ")) }
}

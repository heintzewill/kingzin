package com.nexusos.ultra.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(themeName: String, accent: Color, onTheme: (String) -> Unit, onClearHistory: () -> Unit) {
    val context = LocalContext.current
    var notice by remember { mutableStateOf("") }
    ScreenColumn {
        SectionHeading("SYSTEM CONFIG", "PERSONALIZAÇÃO E PRIVACIDADE", accent)
        Panel("CORES DA INTERFACE", accent) {
            listOf("CYAN", "GREEN", "PURPLE", "AMBER").forEach { theme ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(theme, color = if (themeName == theme) accent else Subtle, fontSize = 13.sp)
                    RadioButton(selected = themeName == theme, onClick = { onTheme(theme) })
                }
            }
        }
        Panel("LAUNCHER PADRÃO", accent) {
            Text("O NEXUS pode substituir a tela inicial do Android. A escolha exige confirmação nas configurações do dispositivo.", color = Subtle, fontSize = 12.sp)
            PrimaryAction("ESCOLHER LAUNCHER", accent, modifier = Modifier.fillMaxWidth()) {
                try {
                    context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                } catch (e: Exception) {
                    notice = "Abra Configurações > Apps padrão > App de início."
                }
            }
        }
        Panel("PRIVACIDADE", accent) {
            Text("A chave de IA e a senha SSH não são gravadas. O histórico de comandos e tema são persistidos localmente no armazenamento privado do aplicativo.", color = Subtle, fontSize = 12.sp)
            PrimaryAction("LIMPAR HISTÓRICO", accent, modifier = Modifier.fillMaxWidth()) {
                onClearHistory()
                notice = "Histórico salvo apagado."
            }
        }
        Panel("INFORMAÇÕES DA VERSÃO", accent) {
            KeyValue("VERSÃO", "0.1.0-alpha", accent)
            KeyValue("TIPO", "PROJETO ORIGINAL", accent)
            KeyValue("API MÍNIMA", "ANDROID 8.0", accent)
            KeyValue("STATUS", "IMPLEMENTAÇÃO ALFA", accent)
        }
        if (notice.isNotBlank()) Text(notice, color = accent)
    }
}

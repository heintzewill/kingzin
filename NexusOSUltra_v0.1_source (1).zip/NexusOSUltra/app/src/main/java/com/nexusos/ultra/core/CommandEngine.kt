package com.nexusos.ultra.core

import android.content.Context
import android.content.Intent
import android.provider.Settings
import java.util.Locale

/** Internal commands only. Never invokes an unrestricted system shell. */
class CommandEngine(private val context: Context, private val apps: AppsRepository, private val device: DeviceRepository) {
    data class Result(val output: String, val navigate: String? = null, val clear: Boolean = false)

    fun execute(raw: String): Result {
        val args = CommandParser.tokenize(raw.trim())
        if (args.isEmpty()) return Result("")
        val withoutPrefix = if (args[0].equals("nexus", true)) args.drop(1) else args
        if (withoutPrefix.isEmpty()) return Result("Use 'help' para conhecer os comandos.")
        val normalized = if (withoutPrefix.size > 1 && withoutPrefix[0].equals("system", true) &&
            withoutPrefix[1].lowercase(Locale.ROOT) in setOf("battery", "memory", "storage", "network")) {
            withoutPrefix.drop(1)
        } else withoutPrefix
        val cmd = normalized[0].lowercase(Locale.ROOT)
        val sub = normalized.drop(1).joinToString(" ").trim()
        val s by lazy { device.snapshot() }
        return when (cmd) {
            "help", "?" -> Result("""
NEXUS SHELL v0.1 • comandos internos
help                    ajuda
status | info           resumo do dispositivo
battery                 nível / temperatura
memory                  memória RAM
storage                 armazenamento
network                 conexão ativa
apps | apps list        listar aplicativos
apps search <nome>      pesquisar aplicativos
apps open <nome>        abrir aplicativo
open <nome>             abrir aplicativo
system                  informações Android
date                    data e hora
settings                configurações Android
theme                   abrir temas
ai                      abrir assistente
globe | global          abrir globo 3D
remote                  abrir acesso remoto
clear                   limpar console
Comandos locais do NEXUS; não são um shell Linux.
            """.trimIndent())
            "clear", "cls" -> Result("", clear = true)
            "status", "info", "dashboard" -> Result("${s.model}\nAndroid ${s.android}\nBateria ${s.batteryPct?.let { "$it%" } ?: "indisponível"}\nRAM ${readableBytes(s.memoryUsed)} / ${readableBytes(s.memoryTotal)}\nRede ${s.transport}\nLeitura ${s.capturedAt}", "home".takeIf { cmd == "dashboard" })
            "battery" -> Result("Bateria: ${s.batteryPct?.let { "$it%" } ?: "indisponível"}\nCarregando: ${if (s.charging) "sim" else "não"}\nTemperatura: ${s.batteryCelsius?.let { "$it °C" } ?: "indisponível"}")
            "memory", "ram" -> Result("RAM total: ${readableBytes(s.memoryTotal)}\nDisponível: ${readableBytes(s.memoryAvailable)}\nEm uso (estimativa): ${readableBytes(s.memoryUsed)} (${s.memoryPct}%)")
            "storage", "disk" -> Result("Armazenamento total: ${readableBytes(s.storageTotal)}\nLivre: ${readableBytes(s.storageAvailable)}\nOcupado: ${s.storagePct}%")
            "network", "net" -> Result("Transporte: ${s.transport}\nInternet validada pelo Android: ${if (s.internetValidated) "sim" else "não"}")
            "apps" -> {
                val action = normalized.getOrNull(1)?.lowercase(Locale.ROOT)
                if (action == "open") {
                    openApp(normalized.drop(2).joinToString(" "))
                } else {
                    val query = when (action) {
                        "list" -> ""
                        "search" -> normalized.drop(2).joinToString(" ")
                        else -> sub
                    }
                    val found = apps.list().filter { query.isBlank() || it.name.contains(query, true) || it.packageName.contains(query, true) }
                    Result(if (found.isEmpty()) "Nenhum aplicativo encontrado." else found.take(30).joinToString("\n") { "• ${it.name}  [${it.packageName}]" } + if (found.size > 30) "\n... ${found.size - 30} outros resultados" else "")
                }
            }
            "open" -> openApp(sub)
            "system" -> Result("Dispositivo: ${s.model}\nAndroid: ${s.android}\nAtividade do sistema: ${s.uptimeMillis / 1000}s")
            "date" -> Result(java.text.DateFormat.getDateTimeInstance().format(java.util.Date()))
            "settings" -> {
                try { context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); Result("Abrindo configurações Android") }
                catch (e: Exception) { Result("Não foi possível abrir as configurações: ${e.message}") }
            }
            "theme", "themes" -> Result("Abrindo configurações de tema.", navigate = "settings")
            "ai" -> Result("Abrindo NEXUS INTELLIGENCE.", navigate = "ai")
            "globe", "global" -> Result("Abrindo NEXUS GLOBAL.", navigate = "global")
            "remote", "ssh" -> Result("Abrindo Remote Hub.", navigate = "remote")
            "monitor", "telemetry" -> Result("Abrindo telemetria do sistema.", navigate = "telemetry")
            else -> Result("Comando desconhecido: ${args[0]}. Digite 'help'.")
        }
    }

    private fun openApp(query: String): Result {
        if (query.isBlank()) return Result("Uso: open <nome do aplicativo>")
        val installed = apps.list()
        val matching = installed.filter { it.name.equals(query, true) || it.packageName.equals(query, true) }
        val app = if (matching.size == 1) matching.first() else installed.firstOrNull { it.name.contains(query, true) }
        return Result(if (app == null) "Aplicativo não encontrado: $query" else apps.open(app))
    }
}

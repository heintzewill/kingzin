package com.nexusos.ultra.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.features.SshExecutor
import kotlinx.coroutines.launch

@Composable
fun RemoteScreen(accent: Color) {
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("22") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("uname -a") }
    var output by remember { mutableStateOf("Nenhuma conexão iniciada.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    ScreenColumn {
        SectionHeading("REMOTE HUB", "SSH COM PINAGEM SHA256 • SESSÃO AUTORIZADA", accent)
        Panel("SERVIDOR SSH", accent) {
            OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Host ou IP do seu servidor") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Porta") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = username, onValueChange = { username = it }, label = { Text("Usuário") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Senha (somente em memória)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("Fingerprint SHA256:... do host") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("Obtenha a fingerprint do administrador do servidor por um canal confiável. Conexões com chaves diferentes são recusadas.", color = Subtle, fontSize = 11.sp)
        }
        Panel("EXECUÇÃO REMOTA EXPLÍCITA", accent) {
            OutlinedTextField(value = command, onValueChange = { command = it }, label = { Text("Comando no seu servidor") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
            PrimaryAction("CONECTAR E EXECUTAR", accent, modifier = Modifier.fillMaxWidth(), enabled = !busy && host.isNotBlank() && username.isNotBlank() && pin.startsWith("SHA256:")) {
                busy = true
                scope.launch {
                    output = try { SshExecutor.execute(host, port.toIntOrNull() ?: 0, username, password, pin, command) }
                    catch (e: Exception) { "Falha SSH: ${e.localizedMessage ?: "erro de conexão"}" }
                    busy = false
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(output, color = accent, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
        Text("Versão alfa: suporte a um comando SSH por conexão. Não inclui ainda sessão shell interativa, chaves privadas ou SFTP. Credenciais não são persistidas.", color = Subtle, fontSize = 11.sp)
    }
}

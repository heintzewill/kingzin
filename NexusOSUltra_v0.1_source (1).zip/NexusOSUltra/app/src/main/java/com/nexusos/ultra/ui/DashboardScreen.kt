package com.nexusos.ultra.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.NexusTab
import com.nexusos.ultra.core.*

@Composable
fun DashboardScreen(snapshot: DeviceSnapshot, accent: Color, onNavigate: (NexusTab) -> Unit) {
    ScreenColumn {
        SectionHeading("COMMAND CENTER", "TELEMETRIA LOCAL • ${snapshot.capturedAt}", accent)
        Panel("SYSTEM OVERVIEW", accent) {
            Text(snapshot.model.uppercase(), color = Color.White, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
            KeyValue("PLATAFORMA", "ANDROID ${snapshot.android}", accent)
            KeyValue("CONECTIVIDADE", snapshot.transport, accent)
            KeyValue("INTERNET", if (snapshot.internetValidated) "VALIDADA" else "NÃO VALIDADA", accent)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Panel("BATTERY", accent, modifier = Modifier.weight(1f)) {
                Text("${snapshot.batteryPct?.let { "$it%" } ?: "N/D"}", color = accent, fontSize = 30.sp, fontFamily = FontFamily.Monospace)
                Text(if (snapshot.charging) "CARREGANDO" else "DESCARREGANDO", color = Subtle, fontSize = 10.sp)
            }
            Panel("MEMORY", accent, modifier = Modifier.weight(1f)) {
                Text("${snapshot.memoryPct}%", color = accent, fontSize = 30.sp, fontFamily = FontFamily.Monospace)
                Text("${readableBytes(snapshot.memoryAvailable)} LIVRE", color = Subtle, fontSize = 10.sp)
            }
        }
        Panel("RESOURCE METRICS", accent) {
            Meter("RAM", snapshot.memoryPct, "${snapshot.memoryPct}%", accent)
            Meter("STORAGE", snapshot.storagePct, "${snapshot.storagePct}%", accent)
            snapshot.batteryPct?.let { Meter("BATTERY", it, "$it%", accent) }
        }
        Panel("QUICK OPERATIONS", accent) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryAction("TERMINAL", accent, onClick = { onNavigate(NexusTab.SHELL) }, modifier = Modifier.weight(1f))
                PrimaryAction("APLICATIVOS", accent, onClick = { onNavigate(NexusTab.APPS) }, modifier = Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryAction("NEXUS AI", accent, onClick = { onNavigate(NexusTab.AI) }, modifier = Modifier.weight(1f))
                PrimaryAction("GLOBAL VIEW", accent, onClick = { onNavigate(NexusTab.GLOBAL) }, modifier = Modifier.weight(1f))
            }
        }
        Text("Os indicadores acima são leituras das APIs do Android; não representam benchmarks nem medições privilegiadas.", fontSize = 11.sp, color = Subtle)
    }
}

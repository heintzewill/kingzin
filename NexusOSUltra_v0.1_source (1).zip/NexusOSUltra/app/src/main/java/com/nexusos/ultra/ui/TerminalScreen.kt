package com.nexusos.ultra.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import com.nexusos.ultra.core.*

private data class TerminalLine(val text: String, val isCommand: Boolean = false)

@Composable
fun TerminalScreen(engine: CommandEngine, prefs: NexusPreferences, accent: Color, onNavigate: (String) -> Unit) {
    val lines = remember {
        mutableStateListOf(TerminalLine("NEXUS SHELL v0.1 — CONSOLE INTERNO"), TerminalLine("Digite 'help' para listar comandos.")).apply {
            prefs.shellHistory.lines().filter { it.isNotBlank() }.takeLast(12).forEach { add(TerminalLine("histórico: $it", true)) }
        }
    }
    var input by remember { mutableStateOf("") }
    val scroll = rememberLazyListState()
    

    fun runCommand(raw: String) {
        if (raw.isBlank()) return
        val result = try { engine.execute(raw) } catch (e: Exception) { CommandEngine.Result("Erro: ${e.localizedMessage}") }
        if (result.clear) lines.clear() else {
            lines.add(TerminalLine("nexus@android $ $raw", true))
            if (result.output.isNotBlank()) lines.add(TerminalLine(result.output))
        }
        if (lines.size > 200) lines.removeRange(0, lines.size - 200)
        prefs.shellHistory = (prefs.shellHistory + "\n" + raw).trim().lines().takeLast(80).joinToString("\n")
        result.navigate?.let(onNavigate)
        input = ""
    }
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) scroll.animateScrollToItem(lines.lastIndex) }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        SectionHeading("NEXUS SHELL", "COMMAND INTERPRETER • SEM ROOT", accent)
        Spacer(Modifier.height(12.dp))
        Surface(
            Modifier.fillMaxWidth().weight(1f), color = Color(0xFF070E17),
            border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .35f)),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(9.dp)
        ) {
            LazyColumn(state = scroll, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(lines) { _, line ->
                    Text(line.text, color = if (line.isCommand) accent else Color(0xFFC2D6DF), fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace, lineHeight = 20.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("❯", color = accent, fontSize = 22.sp, modifier = Modifier.padding(end = 7.dp))
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("help | battery | apps ...", fontSize = 12.sp) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { runCommand(input) })
            )
            Spacer(Modifier.width(6.dp))
            PrimaryAction("RUN", accent, onClick = { runCommand(input) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 7.dp)) {
            listOf("help", "status", "apps", "clear").forEach { cmd ->
                TextButton(onClick = { runCommand(cmd) }) { Text(cmd, color = accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

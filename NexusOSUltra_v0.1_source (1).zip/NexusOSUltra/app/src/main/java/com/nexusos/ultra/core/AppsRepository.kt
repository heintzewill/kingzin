package com.nexusos.ultra.core

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo


data class LaunchableApp(val name: String, val packageName: String, val activityName: String)

class AppsRepository(private val context: Context) {
    fun list(): List<LaunchableApp> {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val matches: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
        return matches.map { info ->
            LaunchableApp(
                name = info.loadLabel(pm).toString(),
                packageName = info.activityInfo.packageName,
                activityName = info.activityInfo.name
            )
        }.distinctBy { "${it.packageName}/${it.activityName}" }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }

    fun open(app: LaunchableApp): String {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                setClassName(app.packageName, app.activityName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            }
            context.startActivity(intent)
            "Abrindo ${app.name}"
        } catch (e: Exception) {
            "Não foi possível abrir ${app.name}: ${e.localizedMessage ?: "erro desconhecido"}"
        }
    }
}

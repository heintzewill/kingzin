package com.nexusos.ultra.features

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.HostKey
import com.jcraft.jsch.HostKeyRepository
import com.jcraft.jsch.JSch
import com.jcraft.jsch.UserInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64

/**
 * Password SSH command execution with SHA-256 host key pinning.
 * Refuses untrusted/unknown hosts: no "StrictHostKeyChecking=no" shortcut.
 */
object SshExecutor {
    suspend fun execute(host: String, port: Int, username: String, password: String, fingerprint: String, command: String): String = withContext(Dispatchers.IO) {
        require(host.isNotBlank() && username.isNotBlank()) { "Informe host e usuário." }
        require(port in 1..65535) { "Porta inválida." }
        require(password.isNotEmpty()) { "Informe a senha SSH." }
        require(command.isNotBlank()) { "Informe o comando remoto." }
        require(fingerprint.startsWith("SHA256:") && fingerprint.length > 12) { "Informe a impressão digital SSH no formato SHA256:..." }
        val jsch = JSch()
        jsch.setHostKeyRepository(PinnedHostKeyRepository(fingerprint))
        val session = jsch.getSession(username, host, port)
        session.setPassword(password)
        session.setConfig("StrictHostKeyChecking", "yes")
        session.setConfig("PreferredAuthentications", "password")
        session.timeout = 20000
        try {
            session.connect(12000)
            val channel = session.openChannel("exec") as ChannelExec
            try {
                channel.setCommand(command)
                channel.setInputStream(null)
                val stream = channel.inputStream
                channel.connect(8000)
                val buffer = ByteArray(4096)
                val output = ByteArrayOutputStream()
                val deadline = System.currentTimeMillis() + 18000
                while (System.currentTimeMillis() < deadline) {
                    while (stream.available() > 0) {
                        val n = stream.read(buffer, 0, minOf(stream.available(), buffer.size))
                        if (n <= 0) break
                        if (output.size() + n > 65536) {
                            output.write("\n[saída truncada em 64 KiB]".toByteArray())
                            return@withContext output.toString("UTF-8")
                        }
                        output.write(buffer, 0, n)
                    }
                    if (channel.isClosed) break
                    Thread.sleep(80)
                }
                val text = output.toString("UTF-8")
                if (!channel.isClosed) "$text\n[tempo limite atingido]"
                else "$text\n[exit code: ${channel.exitStatus}]"
            } finally {
                channel.disconnect()
            }
        } finally {
            session.disconnect()
        }
    }
}

private class PinnedHostKeyRepository(expected: String) : HostKeyRepository {
    private val pin = expected.trim().removePrefix("SHA256:").trimEnd('=')
    override fun check(host: String, key: ByteArray): Int {
        val received = Base64.getEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(key))
        val a = received.toByteArray(Charsets.US_ASCII)
        val b = pin.toByteArray(Charsets.US_ASCII)
        return if (MessageDigest.isEqual(a, b)) HostKeyRepository.OK else HostKeyRepository.CHANGED
    }
    override fun add(hostkey: HostKey, ui: UserInfo?) { /* deliberately never auto-trust */ }
    override fun remove(host: String, type: String) { }
    override fun remove(host: String, type: String, key: ByteArray) { }
    override fun getKnownHostsRepositoryID(): String = "NEXUS SHA256 pinned host"
    override fun getHostKey(): Array<HostKey> = emptyArray()
    override fun getHostKey(host: String, type: String): Array<HostKey> = emptyArray()
}

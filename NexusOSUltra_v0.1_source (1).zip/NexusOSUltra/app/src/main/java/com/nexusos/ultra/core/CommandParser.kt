package com.nexusos.ultra.core

/** Platform-independent parser; preserves quoted phrases and escaped characters. */
object CommandParser {
    fun tokenize(input: String): List<String> {
        val out = mutableListOf<String>()
        val item = StringBuilder()
        var quote: Char? = null
        var escaped = false
        var active = false
        for (char in input) {
            when {
                escaped -> { item.append(char); active = true; escaped = false }
                char == '\\' -> { escaped = true; active = true }
                quote != null && char == quote -> { quote = null }
                quote != null -> { item.append(char); active = true }
                char == '\'' || char == '"' -> { quote = char; active = true }
                char.isWhitespace() -> {
                    if (active) { out += item.toString(); item.clear(); active = false }
                }
                else -> { item.append(char); active = true }
            }
        }
        if (escaped) item.append('\\')
        require(quote == null) { "Aspas não fechadas no comando." }
        if (active) out += item.toString()
        return out
    }
}

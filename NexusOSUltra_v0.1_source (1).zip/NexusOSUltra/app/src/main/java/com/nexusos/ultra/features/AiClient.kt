package com.nexusos.ultra.features

import com.nexusos.ultra.core.DeviceSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Explicit user-supplied API key; no key persistence or telemetry transmission. */
object AiClient {
    fun localHelp(question: String, snapshot: DeviceSnapshot): String {
        val q = question.lowercase()
        return when {
            "bateria" in q || "battery" in q -> "Leitura local: bateria ${snapshot.batteryPct?.let { "$it%" } ?: "indisponível"}; temperatura ${snapshot.batteryCelsius?.let { "$it °C" } ?: "indisponível"}. O modo ECO do app pode reduzir animações e atualizações."
            "ram" in q || "memória" in q -> "Leitura local: ${snapshot.memoryPct}% da RAM está em uso (estimativa baseada na memória disponível reportada pelo Android). Considere fechar tarefas pesadas caso o sistema esteja lento."
            "rede" in q || "wi-fi" in q || "internet" in q -> "Leitura local: conexão ${snapshot.transport}; internet ${if (snapshot.internetValidated) "validada pelo Android" else "não validada pelo Android"}. Use a aba GLOBAL para testar um endpoint HTTPS."
            "comando" in q || "terminal" in q || "help" in q -> "O console NEXUS usa comandos internos. Experimente: help, status, battery, memory, storage, network, apps, open, ai, global. Não é um shell Linux."
            "app" in q || "aplicativo" in q -> "Acesse APPS para buscar e iniciar aplicativos instalados. Para definir o NEXUS como launcher principal, abra CONFIG e selecione 'Escolher launcher padrão'."
            else -> "Assistente local de regras (sem IA generativa): posso explicar bateria, memória, rede, comandos e aplicativos. Para conversar com um modelo de IA, informe sua chave de API temporariamente nesta tela."
        }
    }

    suspend fun askOpenAi(apiKey: String, model: String, question: String): String = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "Informe uma chave de API válida." }
        val safeModel = model.trim().ifEmpty { "gpt-4o-mini" }
        val conn = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 12000
            conn.readTimeout = 30000
            conn.setRequestProperty("Authorization", "Bearer $apiKey")
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.doOutput = true
            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", "Você é o NEXUS AI. Responda em português, seja preciso. Você não controla o aparelho e não deve alegar que executou ações."))
                .put(JSONObject().put("role", "user").put("content", question))
            val payload = JSONObject().put("model", safeModel).put("messages", messages).put("max_tokens", 600)
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val response = (if (status in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (status !in 200..299) {
                val apiError = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                throw IllegalStateException("API HTTP $status: ${apiError ?: "Falha na solicitação"}")
            }
            JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        } finally {
            conn.disconnect()
        }
    }
}

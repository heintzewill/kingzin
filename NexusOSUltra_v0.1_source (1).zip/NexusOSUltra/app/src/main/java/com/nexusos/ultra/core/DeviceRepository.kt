package com.nexusos.ultra.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All presented values come from system APIs; missing measurements are null. */
data class DeviceSnapshot(
    val model: String,
    val android: String,
    val batteryPct: Int?,
    val charging: Boolean,
    val batteryCelsius: Float?,
    val memoryTotal: Long,
    val memoryAvailable: Long,
    val storageTotal: Long,
    val storageAvailable: Long,
    val transport: String,
    val internetValidated: Boolean,
    val uptimeMillis: Long,
    val capturedAt: String
) {
    val memoryUsed: Long get() = (memoryTotal - memoryAvailable).coerceAtLeast(0)
    val storageUsed: Long get() = (storageTotal - storageAvailable).coerceAtLeast(0)
    val memoryPct: Int get() = if (memoryTotal > 0L) (100 * memoryUsed / memoryTotal).toInt() else 0
    val storagePct: Int get() = if (storageTotal > 0L) (100 * storageUsed / storageTotal).toInt() else 0
}

class DeviceRepository(private val context: Context) {
    fun snapshot(): DeviceSnapshot {
        val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (100 * level / scale).coerceIn(0, 100) else null
        val batteryTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val ram = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(ram)
        val disk = StatFs(Environment.getDataDirectory().absolutePath)
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val transport = when {
            caps == null -> "DESCONECTADO"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MÓVEL"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "OUTRA"
        }
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        return DeviceSnapshot(
            model = "${Build.MANUFACTURER} ${Build.MODEL}",
            android = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            batteryPct = pct,
            charging = charging,
            batteryCelsius = if (batteryTemp >= 0) batteryTemp / 10f else null,
            memoryTotal = ram.totalMem,
            memoryAvailable = ram.availMem,
            storageTotal = disk.totalBytes,
            storageAvailable = disk.availableBytes,
            transport = transport,
            internetValidated = validated,
            uptimeMillis = SystemClock.elapsedRealtime(),
            capturedAt = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        )
    }
}

fun readableBytes(bytes: Long): String {
    val gb = bytes.toDouble() / 1_073_741_824.0
    return String.format(Locale.US, "%.2f GiB", gb)
}

package com.nexusos.ultra.ui

import android.content.pm.PackageManager
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.core.*

@Composable
fun AppsScreen(repo: AppsRepository, accent: Color) {
    var search by remember { mutableStateOf("") }
    val apps = remember { repo.list() }
    val visible = remember(search, apps) { apps.filter { search.isBlank() || it.name.contains(search, true) || it.packageName.contains(search, true) } }
    var notice by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
        SectionHeading("APPLICATION HUB", "${apps.size} LANÇADORES DETECTADOS", accent)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = search, onValueChange = { search = it },
            label = { Text("Pesquisar aplicativos") },
            placeholder = { Text("Nome ou pacote") },
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        if (notice.isNotBlank()) Text(notice, color = accent, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(visible, key = { "${it.packageName}/${it.activityName}" }) { app ->
                Surface(
                    onClick = { notice = repo.open(app) },
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF0D1A28),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .2f))
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("▣", color = accent, fontSize = 24.sp)
                        Column(Modifier.weight(1f)) {
                            Text(app.name, color = Color.White, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                            Text(app.packageName, color = Subtle, fontSize = 10.sp, maxLines = 1)
                        }
                        Text("↗", color = accent, fontSize = 17.sp)
                    }
                }
            }
            if (visible.isEmpty()) item { Text("Nenhum aplicativo encontrado.", color = Subtle) }
        }
    }
}

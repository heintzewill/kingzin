package com.nexusos.ultra.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.features.NetworkProbe
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.min

@Composable
fun GlobalScreen(accent: Color) {
    val animation = rememberInfiniteTransition(label = "earth")
    val angle by animation.animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(35000, easing = LinearEasing), RepeatMode.Restart),
        label = "rotation"
    )
    var url by remember { mutableStateOf("https://www.google.com") }
    var output by remember { mutableStateOf("Ainda não testado") }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    ScreenColumn {
        SectionHeading("GLOBAL VIEW", "GLOBO 3D PROJETADO • DIAGNÓSTICOS HTTPS", accent)
        Panel("CYBER EARTH • VISUALIZAÇÃO GRÁFICA", accent) {
            Canvas(Modifier.fillMaxWidth().height(265.dp).background(Color(0xFF07111E), RoundedCornerShape(8.dp))) {
                val radius = min(size.width, size.height) * .42f
                val center = Offset(size.width / 2, size.height / 2)
                drawCircle(accent.copy(alpha = .045f), radius * 1.18f, center)
                drawCircle(Color(0xFF0B2A3B), radius, center)
                drawCircle(accent.copy(alpha = .65f), radius, center, style = Stroke(width = 2.dp.toPx()))
                fun project(lat: Double, lon: Double): Pair<Offset, Boolean> {
                    val phi = Math.toRadians(lat)
                    val theta = Math.toRadians(lon) + angle
                    val x = cos(phi) * sin(theta)
                    val y = sin(phi)
                    val z = cos(phi) * cos(theta)
                    return Offset(center.x + radius * x.toFloat(), center.y - radius * y.toFloat()) to (z >= 0)
                }
                for (lat in -75..75 step 15) {
                    var last: Offset? = null
                    for (lon in -180..180 step 4) {
                        val (point, visible) = project(lat.toDouble(), lon.toDouble())
                        if (visible && last != null) drawLine(accent.copy(alpha = .24f), last, point, strokeWidth = 1.dp.toPx())
                        last = if (visible) point else null
                    }
                }
                for (lon in -180 until 180 step 15) {
                    var last: Offset? = null
                    for (lat in -90..90 step 4) {
                        val (point, visible) = project(lat.toDouble(), lon.toDouble())
                        if (visible && last != null) drawLine(accent.copy(alpha = .25f), last, point, strokeWidth = 1.dp.toPx())
                        last = if (visible) point else null
                    }
                }
                drawLine(accent.copy(alpha = .5f), Offset(center.x - radius * 1.15f, center.y), Offset(center.x + radius * 1.15f, center.y), 1.dp.toPx())
            }
            Text("Modelo geométrico animado. Não representa conexões mundiais ou tráfego real.", color = Subtle, fontSize = 10.sp)
        }
        Panel("HTTPS ENDPOINT PROBE", accent) {
            OutlinedTextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("URL HTTPS para testar") })
            PrimaryAction("TESTAR CONEXÃO", accent, modifier = Modifier.fillMaxWidth(), enabled = !loading) {
                loading = true
                scope.launch {
                    output = try { NetworkProbe.test(url) } catch (e: Exception) { "Falha: ${e.localizedMessage ?: "erro de rede"}" }
                    loading = false
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text(output, color = accent, fontSize = 12.sp)
        }
    }
}

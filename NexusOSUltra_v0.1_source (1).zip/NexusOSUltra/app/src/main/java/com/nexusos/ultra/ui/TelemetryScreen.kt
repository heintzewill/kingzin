package com.nexusos.ultra.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.core.*

@Composable
fun TelemetryScreen(snapshot: DeviceSnapshot, accent: Color) {
    val ramHistory = remember { mutableStateListOf<Int>() }
    val diskHistory = remember { mutableStateListOf<Int>() }
    LaunchedEffect(snapshot.capturedAt) {
        if (ramHistory.size >= 30) ramHistory.removeAt(0)
        if (diskHistory.size >= 30) diskHistory.removeAt(0)
        ramHistory.add(snapshot.memoryPct)
        diskHistory.add(snapshot.storagePct)
    }
    ScreenColumn {
        SectionHeading("SYSTEM TELEMETRY", "DADOS REAIS • ATUALIZAÇÃO A CADA 5s", accent)
        Panel("MEMORY ANALYSIS", accent) {
            KeyValue("TOTAL", readableBytes(snapshot.memoryTotal), accent)
            KeyValue("DISPONÍVEL", readableBytes(snapshot.memoryAvailable), accent)
            KeyValue("UTILIZADA (EST.)", readableBytes(snapshot.memoryUsed), accent)
            Meter("USO", snapshot.memoryPct, "${snapshot.memoryPct}%", accent)
            TinySpark(ramHistory, accent)
            Text("Histórico local desde a abertura desta tela", color = Subtle, fontSize = 10.sp)
        }
        Panel("STORAGE ANALYSIS", accent) {
            KeyValue("TOTAL", readableBytes(snapshot.storageTotal), accent)
            KeyValue("DISPONÍVEL", readableBytes(snapshot.storageAvailable), accent)
            Meter("OCUPAÇÃO", snapshot.storagePct, "${snapshot.storagePct}%", accent)
            TinySpark(diskHistory, accent)
        }
        Panel("POWER SYSTEM", accent) {
            KeyValue("CARGA", snapshot.batteryPct?.let { "$it%" } ?: "N/D", accent)
            KeyValue("STATUS", if (snapshot.charging) "CARREGANDO" else "NÃO CARREGANDO", accent)
            KeyValue("TEMPERATURA", snapshot.batteryCelsius?.let { "$it °C" } ?: "N/D", accent)
        }
        Panel("DEVICE INFORMATION", accent) {
            KeyValue("MODELO", snapshot.model, accent)
            KeyValue("ANDROID", snapshot.android, accent)
            KeyValue("REDE", snapshot.transport, accent)
            KeyValue("UPTIME", "${snapshot.uptimeMillis / 3_600_000} horas", accent)
            KeyValue("COLETA", snapshot.capturedAt, accent)
        }
        Text("CPU global e temperaturas de componentes não são mostradas: o Android não garante acesso confiável a esses valores em todos os aparelhos.", color = Subtle, fontSize = 11.sp)
    }
}

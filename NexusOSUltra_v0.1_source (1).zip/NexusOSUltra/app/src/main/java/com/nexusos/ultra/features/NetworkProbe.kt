package com.nexusos.ultra.features

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object NetworkProbe {
    suspend fun test(raw: String): String = withContext(Dispatchers.IO) {
        val url = URL(raw.trim())
        require(url.protocol.equals("https", ignoreCase = true)) { "Use somente URL HTTPS." }
        require(url.host.isNotBlank()) { "Host inválido." }
        val start = SystemClock.elapsedRealtime()
        val connection = url.openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "HEAD"
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.instanceFollowRedirects = false
            val status = connection.responseCode
            "HTTPS $status • ${SystemClock.elapsedRealtime() - start} ms • ${url.host}"
        } finally {
            connection.disconnect()
        }
    }
}

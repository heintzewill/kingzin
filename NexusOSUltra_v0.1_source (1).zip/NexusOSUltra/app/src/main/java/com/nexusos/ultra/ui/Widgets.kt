package com.nexusos.ultra.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.StrokeCap

val Subtle = Color(0xFF83A5B5)

@Composable
fun Panel(title: String, accent: Color, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier,
        color = Color(0xFF0C1724),
        border = BorderStroke(1.dp, accent.copy(alpha = .25f)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = accent, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text("◈", color = accent.copy(alpha = .6f), fontSize = 13.sp)
            }
            HorizontalDivider(color = accent.copy(alpha = .15f))
            content()
        }
    }
}

@Composable
fun KeyValue(key: String, value: String, accent: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(key, color = Subtle, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = accent, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Meter(label: String, value: Int, valueLabel: String, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Subtle, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Text(valueLabel, color = accent, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
        LinearProgressIndicator(
            progress = { value.coerceIn(0,100) / 100f },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = accent, trackColor = accent.copy(alpha = .15f)
        )
    }
}

@Composable
fun PrimaryAction(label: String, accent: Color, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF041016))
    ) { Text(label, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun SectionHeading(head: String, sub: String, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(head, color = Color(0xFFF0FAFE), fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 19.sp)
        Text(sub, color = Subtle, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}

@Composable
fun TinySpark(values: List<Int>, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(64.dp)) {
        if (values.size < 2) return@Canvas
        val path = Path()
        values.forEachIndexed { idx, value ->
            val x = idx.toFloat() * size.width / (values.size - 1)
            val y = size.height * (1f - value.coerceIn(0,100).toFloat() / 100f)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = accent, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round))
    }
}

package com.nexusos.ultra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.core.*
import com.nexusos.ultra.ui.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 10, 17)
        window.navigationBarColor = android.graphics.Color.rgb(5, 10, 17)
        setContent { NexusApp() }
    }
}

private val Ink = Color(0xFF050A11)
private val SurfaceNexus = Color(0xFF0C1825)
private val TextNexus = Color(0xFFE5F4FA)

enum class NexusTab(val label: String, val key: String) {
    HOME("◈ HOME", "home"), SHELL("⌘ SHELL", "shell"),
    APPS("▦ APPS", "apps"), TELEMETRY("▤ SYS", "telemetry"),
    AI("✦ AI", "ai"), GLOBAL("◎ GLOBAL", "global"),
    REMOTE("↗ REMOTE", "remote"), SETTINGS("⚙ CONFIG", "settings")
}

fun themeAccent(value: String) = when (value) {
    "GREEN" -> Color(0xFF00FF88)
    "PURPLE" -> Color(0xFFA985FF)
    "AMBER" -> Color(0xFFFFC062)
    else -> Color(0xFF00E5F6)
}

@Composable
fun NexusApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preferences = remember { NexusPreferences(context) }
    val device = remember { DeviceRepository(context) }
    val apps = remember { AppsRepository(context) }
    val engine = remember { CommandEngine(context, apps, device) }
    var themeName by remember { mutableStateOf(preferences.theme) }
    var selected by remember { mutableStateOf(NexusTab.HOME) }
    var snapshot by remember { mutableStateOf(device.snapshot()) }
    val accent = themeAccent(themeName)

    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            try { snapshot = device.snapshot() } catch (_: Exception) { /* keep last valid snapshot */ }
        }
    }
    val colors = darkColorScheme(
        primary = accent, onPrimary = Ink,
        background = Ink, onBackground = TextNexus,
        surface = SurfaceNexus, onSurface = TextNexus,
        surfaceVariant = Color(0xFF122639),
        outline = accent.copy(alpha = 0.35f),
        secondary = Color(0xFF93BACB)
    )
    MaterialTheme(colorScheme = colors, typography = Typography()) {
        Column(Modifier.fillMaxSize().background(Ink).safeDrawingPadding()) {
            Header(accent, snapshot)
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                NexusTab.entries.forEach { tab ->
                    val active = tab == selected
                    Surface(
                        onClick = { selected = tab },
                        color = if (active) accent.copy(alpha = 0.18f) else SurfaceNexus,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) accent else accent.copy(alpha = 0.20f)),
                        shape = RoundedCornerShape(7.dp)
                    ) {
                        Text(
                            tab.label, fontFamily = FontFamily.Monospace,
                            color = if (active) accent else Color(0xFF86B0BD),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                }
            }
            HorizontalDivider(color = accent.copy(alpha = 0.20f))
            Box(Modifier.fillMaxWidth().weight(1f)) {
                when (selected) {
                    NexusTab.HOME -> DashboardScreen(snapshot, accent, onNavigate = { selected = it })
                    NexusTab.SHELL -> TerminalScreen(engine, preferences, accent, onNavigate = { key ->
                        selected = NexusTab.entries.firstOrNull { it.key == key } ?: selected
                    })
                    NexusTab.APPS -> AppsScreen(apps, accent)
                    NexusTab.TELEMETRY -> TelemetryScreen(snapshot, accent)
                    NexusTab.AI -> AiScreen(snapshot, accent)
                    NexusTab.GLOBAL -> GlobalScreen(accent)
                    NexusTab.REMOTE -> RemoteScreen(accent)
                    NexusTab.SETTINGS -> SettingsScreen(
                        themeName, accent,
                        onTheme = { themeName = it; preferences.theme = it },
                        onClearHistory = { preferences.clearHistory() }
                    )
                }
            }
            HorizontalDivider(color = accent.copy(alpha = .25f))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("● SYSTEM ONLINE", color = accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text("OMEGA 0.1 ALPHA  ·  ${snapshot.capturedAt}", color = Color(0xFF7393A7), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun Header(accent: Color, snapshot: DeviceSnapshot) {
    Box(Modifier.fillMaxWidth().height(90.dp).background(Ink)) {
        Canvas(Modifier.fillMaxSize()) {
            val s = 26.dp.toPx()
            for (i in 0..(size.width / s).toInt()) {
                val x = i * s
                drawLine(accent.copy(alpha = 0.05f), androidx.compose.ui.geometry.Offset(x, 0f), androidx.compose.ui.geometry.Offset(x, size.height))
            }
            for (i in 0..(size.height / s).toInt()) {
                val y = i * s
                drawLine(accent.copy(alpha = 0.05f), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y))
            }
            drawLine(accent.copy(alpha = .60f), androidx.compose.ui.geometry.Offset(0f, size.height - 1f), androidx.compose.ui.geometry.Offset(size.width, size.height - 1f))
        }
        Row(
            Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("NEXUS", color = accent, fontSize = 29.sp, letterSpacing = 5.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                Text("OS ULTRA  /  PROJECT OMEGA", color = Color(0xFF95AEC1), fontSize = 10.sp, letterSpacing = 1.2.sp, fontFamily = FontFamily.Monospace)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${snapshot.batteryPct?.let { "$it%" } ?: "--"}  ▰", color = accent, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                Text(snapshot.transport, color = Color(0xFF8FAAB7), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text("v0.1", color = Color(0xFF617A89), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

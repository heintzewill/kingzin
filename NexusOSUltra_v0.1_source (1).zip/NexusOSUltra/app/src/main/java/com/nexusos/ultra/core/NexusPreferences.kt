package com.nexusos.ultra.core

import android.content.Context

class NexusPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("nexus_preferences", Context.MODE_PRIVATE)
    var theme: String
        get() = prefs.getString("theme", "CYAN") ?: "CYAN"
        set(value) { prefs.edit().putString("theme", value).apply() }

    var shellHistory: String
        get() = prefs.getString("shell_history", "") ?: ""
        set(value) { prefs.edit().putString("shell_history", value.takeLast(8000)).apply() }

    fun clearHistory() { prefs.edit().remove("shell_history").apply() }
}

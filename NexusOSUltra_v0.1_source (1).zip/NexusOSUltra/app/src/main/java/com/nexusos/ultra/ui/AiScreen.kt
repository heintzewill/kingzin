package com.nexusos.ultra.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexusos.ultra.core.DeviceSnapshot
import com.nexusos.ultra.features.AiClient
import kotlinx.coroutines.launch

private data class ChatLine(val fromUser: Boolean, val content: String, val online: Boolean = false)

@Composable
fun AiScreen(snapshot: DeviceSnapshot, accent: Color) {
    var question by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") } // Memory-only, never persisted.
    var model by remember { mutableStateOf("gpt-4o-mini") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatLine(false, "NEXUS INTELLIGENCE online. Modo local de regras ativo. Para IA generativa, forneça sua própria chave temporária.")) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        SectionHeading("NEXUS INTELLIGENCE", "MODO LOCAL + PROVEDOR OPCIONAL", accent)
        Spacer(Modifier.height(10.dp))
        Panel("CONFIGURAÇÃO DA IA", accent) {
            OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Chave da API (opcional)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(value = model, onValueChange = { model = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Modelo da API") }, singleLine = true)
            Text("Chave mantida apenas na memória desta tela. Nenhuma telemetria é enviada automaticamente.", color = Subtle, fontSize = 10.sp)
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { line ->
                Surface(color = if (line.fromUser) accent.copy(alpha = .13f) else Color(0xFF102333),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(if (line.fromUser) "VOCÊ" else if (line.online) "NEXUS AI • API" else "NEXUS • REGRAS LOCAIS", color = accent, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Spacer(Modifier.height(5.dp))
                        Text(line.content, color = Color(0xFFD8EDF2), fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
        }
        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = accent)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = question, onValueChange = { question = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Pergunte sobre o dispositivo ou um comando") }, maxLines = 3)
        PrimaryAction("ENVIAR MENSAGEM", accent, modifier = Modifier.fillMaxWidth(), enabled = !busy && question.isNotBlank()) {
            val q = question.trim()
            question = ""
            messages.add(ChatLine(true, q))
            if (apiKey.isBlank()) {
                messages.add(ChatLine(false, AiClient.localHelp(q, snapshot)))
            } else {
                busy = true
                scope.launch {
                    val reply = try { AiClient.askOpenAi(apiKey, model, q) } catch (e: Exception) { "Falha na API: ${e.localizedMessage ?: "erro desconhecido"}" }
                    messages.add(ChatLine(false, reply, online = true))
                    busy = false
                }
            }
        }
    }
}

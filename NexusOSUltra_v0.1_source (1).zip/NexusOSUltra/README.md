# NEXUS OS ULTRA — PROJECT OMEGA

**Versão 0.1.0-alpha · Implementação Android nativa em Kotlin + Jetpack Compose**

Primeira implementação do projeto de launcher futurista, console interno, telemetria do dispositivo, assistente local / IA opcional, globo animado e módulo remoto SSH.

**Estado de validação:** o código foi produzido nesta sessão, porém **o APK ainda não foi compilado nem executado em um dispositivo**. O ambiente de autoria não dispõe de Android SDK/Gradle nem de conexão para instalar as dependências. Um parser puro Kotlin foi compilado isoladamente com sucesso. O workflow GitHub Actions está incluído para **tentar** a primeira compilação Android em ambiente apropriado. Qualquer falha do CI precisa ser corrigida antes de considerar o APK pronto.

## Quatro sistemas integrados

| Sistema | Implementado nesta alpha | Limitações |
| --- | --- | --- |
| **NEXUS CORE** | Launcher selecionável, lista/pesquisa/abertura de aplicativos, console de comandos, histórico simples e temas | Console de comandos **internos**, não shell Linux / PTY; sem widgets externos |
| **NEXUS TELEMETRY** | Bateria, temperatura da bateria, RAM, armazenamento, informações de dispositivo, transporte de rede e histórico RAM/armazenamento nesta sessão | Sem acesso prometido à CPU global ou temperaturas privadas |
| **NEXUS INTELLIGENCE** | Assistente local baseado em regras + requisições opcionais à API Chat Completions com chave digitada pelo usuário | Não executa comandos ou ferramentas autonomamente; chave não salva |
| **NEXUS GLOBAL** | Globo 3D geométrico projetado em Canvas com animação, diagnóstico HTTPS, execução de um comando SSH com fingerprint SHA256 obrigatória | Globo sem dados de tráfego real; SSH sem shell interativo ou SFTP nesta versão |

## Requisitos

- Android 8.0 (API 26) ou superior; alvo API 35.
- Para compilação local: JDK 17, Android SDK 35, Gradle 8.9, Android Gradle Plugin 8.7.3.
- Para compilação usando apenas o celular: conta GitHub e GitHub Actions (instruções abaixo).

## Compilar no GitHub sem PC

1. No navegador do celular, crie um repositório **privado** no GitHub, por exemplo `NexusOSUltra`.
2. Envie **o conteúdo desta pasta**, preservando `.github/workflows/android.yml`. Use um editor Git no celular ou envie os arquivos pelo editor web do GitHub. A pasta `.github` deve estar na raiz do repositório.
3. Abra **Actions → Build NEXUS OS ULTRA APK → Run workflow**. Caso a aba Actions esteja desabilitada, habilite-a nas configurações do repositório.
4. Espere o workflow concluir. Se houver erro, consulte o log e corrija o projeto; **nenhum APK existe até o build ficar verde**.
5. Após build bem-sucedido, abra a execução e baixe o artefato `NexusOSUltra-v0.1.0-debug-apk`.
6. Extraia o ZIP do artefato no telefone e instale `app-debug.apk` depois de permitir a instalação para o aplicativo usado no download, se o Android solicitar.
7. Se desejar usar como launcher padrão, abra **CONFIG → ESCOLHER LAUNCHER** e escolha NEXUS OS ULTRA.

> O workflow gera APK **debug** assinado automaticamente com chave de depuração (não distribuição pública). Um APK release exigirá configuração segura de assinatura.

## Compilar em computador com SDK instalado

```bash
# Instalar JDK 17, Android SDK Platform 35 e Gradle 8.9.
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
# Saída: app/build/outputs/apk/debug/app-debug.apk
```

## Principais comandos do console

```text
help
status
battery
memory
storage
network
apps
apps fire
open camera
system
date
settings
theme
ai
globe
remote
monitor
clear
```

## Segurança e privacidade

- Nenhuma permissão de root é solicitada.
- Android: apenas `INTERNET` e `ACCESS_NETWORK_STATE` são usadas.
- Tokens de IA e senhas SSH não são persistidos no disco.
- A API de IA é acionada **somente** após digitar uma chave e enviar uma mensagem; nenhuma métrica do dispositivo é compartilhada automaticamente.
- O SSH só conecta se a chave pública do servidor corresponder à fingerprint SHA256 informada pelo usuário, obtida por canal confiável.
- A execução SSH ocorre apenas após o toque do usuário. Não existe execução remota automática.
- O app foi criado independentemente dos arquivos e códigos do APK de referência. Nenhum recurso daquele APK foi incluído.

## O que falta para a versão 1.0

- Testar o APK em Android real, corrigir eventuais incompatibilidades e otimizar UX.
- Terminal local PTY/Linux completo.
- Editor de arquivos e código.
- Widgets Android e organização avançada do launcher.
- SFTP, chaves privadas SSH e shell remoto interativo.
- Pins do globo associados aos servidores cadastrados.
- Integração de IA com ferramentas locais e confirmações tipadas.
- Editor de automações e regras agendadas.
- Testes instrumentados e benchmarking.
- Assinatura de APK release e distribuição.

Consulte `docs/ROADMAP.md` para os detalhes de desenvolvimento.
